package com.example.floatingtext

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent { AppTheme { App() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()                       // ডার্ক মোড
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme() else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme) { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background, content = content) }
}

private val COLORS = listOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFF69F0AE, 0xFF40C4FF, 0xFFFF5252, 0xFFFFA726).map { it.toInt() }
private val MODES = listOf("BOUNCE" to "বাউন্স", "RANDOM" to "র‍্যান্ডম", "SCROLL" to "স্ক্রল", "STATIC" to "স্থির")

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cfg by Prefs.flow(ctx).collectAsState(initial = Cfg())
    var text by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { text = Prefs.flow(ctx).first().texts }
    fun save(n: Cfg) { scope.launch { Prefs.save(ctx, n) } }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp).statusBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {

        Text("Floating Text Pro", style = MaterialTheme.typography.headlineSmall)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                if (!Settings.canDrawOverlays(ctx))
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                else ctx.startForegroundService(Intent(ctx, FloatingTextService::class.java))
            }) { Text("চালু করুন") }
            OutlinedButton(onClick = { ctx.stopService(Intent(ctx, FloatingTextService::class.java)) }) { Text("বন্ধ করুন") }
        }

        OutlinedTextField(text, { text = it; save(cfg.copy(texts = it)) },
            label = { Text("লেখা (প্রতি লাইনে একটি)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)

        Text("রঙ")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            COLORS.forEach { c ->
                Box(Modifier.size(36.dp).clip(CircleShape).background(Color(c))
                    .border(if (cfg.color == c) 3.dp else 1.dp, MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable { save(cfg.copy(color = c)) })
            }
        }

        Text("মুভমেন্ট")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MODES.forEach { (k, l) -> FilterChip(cfg.mode == k, { save(cfg.copy(mode = k)) }, { Text(l) }) }
        }

        Sld("সাইজ", cfg.sizeSp, 12f..60f, "${cfg.sizeSp.toInt()}sp") { save(cfg.copy(sizeSp = it)) }
        Sld("স্বচ্ছতা", cfg.alpha, 0.2f..1f, "${(cfg.alpha * 100).toInt()}%") { save(cfg.copy(alpha = it)) }
        Sld("গতি", cfg.speed, 20f..300f, "${cfg.speed.toInt()}") { save(cfg.copy(speed = it)) }
        Sld("লেখা বদলের সময়", cfg.rotateSec.toFloat(), 2f..30f, "${cfg.rotateSec}s") { save(cfg.copy(rotateSec = it.toInt())) }

        Sw("ধরে টেনে সরানো (অ্যানিমেশন থামবে, নিচের অ্যাপে টাচ যাবে না)", cfg.draggable) { save(cfg.copy(draggable = it)) }
        Sw("ফোন চালু হলে অটো-স্টার্ট", cfg.autoStart) { save(cfg.copy(autoStart = it)) }
        Sw("শিডিউল (নির্দিষ্ট সময়ে দেখাবে)", cfg.schedOn) { save(cfg.copy(schedOn = it)) }
        if (cfg.schedOn) {
            Sld("শুরু", cfg.startH.toFloat(), 0f..23f, "${cfg.startH}:00") { save(cfg.copy(startH = it.toInt())) }
            Sld("শেষ", cfg.endH.toFloat(), 0f..23f, "${cfg.endH}:00") { save(cfg.copy(endH = it.toInt())) }
        }

        HorizontalDivider()
        Text("ব্যাটারি গাইড", style = MaterialTheme.typography.titleMedium)
        Text("Xiaomi/Oppo/Vivo/Samsung ফোনে অ্যাপটিকে \"No restrictions\" ও \"Autostart\" দিন, নইলে সিস্টেম সার্ভিস বন্ধ করে দিতে পারে।",
            style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) {
            Text("ব্যাটারি সেটিংস খুলুন")
        }
    }
}

@Composable
fun Sld(label: String, v: Float, r: ClosedFloatingPointRange<Float>, show: String, on: (Float) -> Unit) {
    Column { Text("$label: $show"); Slider(v, on, valueRange = r) }
}

@Composable
fun Sw(label: String, v: Boolean, on: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f)); Switch(v, on)
    }
}
