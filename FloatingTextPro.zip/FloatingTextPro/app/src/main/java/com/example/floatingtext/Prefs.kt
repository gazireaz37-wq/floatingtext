package com.example.floatingtext

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

data class Cfg(
    val texts: String = "আমার লেখা",     // প্রতি লাইনে একটি লেখা
    val color: Int = 0xFFFFFFFF.toInt(),
    val sizeSp: Float = 22f,
    val alpha: Float = 0.9f,
    val speed: Float = 80f,              // dp/সেকেন্ড
    val mode: String = "BOUNCE",         // BOUNCE, RANDOM, SCROLL, STATIC
    val rotateSec: Int = 5,
    val draggable: Boolean = false,
    val schedOn: Boolean = false,
    val startH: Int = 8,
    val endH: Int = 22,
    val autoStart: Boolean = false,
)

private val Context.ds by preferencesDataStore("floating_settings")

object Prefs {
    private val TEXTS = stringPreferencesKey("texts")
    private val COLOR = intPreferencesKey("color")
    private val SIZE = floatPreferencesKey("size")
    private val ALPHA = floatPreferencesKey("alpha")
    private val SPEED = floatPreferencesKey("speed")
    private val MODE = stringPreferencesKey("mode")
    private val ROT = intPreferencesKey("rot")
    private val DRAG = booleanPreferencesKey("drag")
    private val SON = booleanPreferencesKey("son")
    private val SH = intPreferencesKey("sh")
    private val EH = intPreferencesKey("eh")
    private val AUTO = booleanPreferencesKey("auto")

    fun flow(c: Context) = c.ds.data.map { p ->
        val d = Cfg()
        Cfg(p[TEXTS] ?: d.texts, p[COLOR] ?: d.color, p[SIZE] ?: d.sizeSp, p[ALPHA] ?: d.alpha,
            p[SPEED] ?: d.speed, p[MODE] ?: d.mode, p[ROT] ?: d.rotateSec, p[DRAG] ?: d.draggable,
            p[SON] ?: d.schedOn, p[SH] ?: d.startH, p[EH] ?: d.endH, p[AUTO] ?: d.autoStart)
    }

    suspend fun save(c: Context, x: Cfg) {
        c.ds.edit { p ->
            p[TEXTS] = x.texts; p[COLOR] = x.color; p[SIZE] = x.sizeSp; p[ALPHA] = x.alpha
            p[SPEED] = x.speed; p[MODE] = x.mode; p[ROT] = x.rotateSec; p[DRAG] = x.draggable
            p[SON] = x.schedOn; p[SH] = x.startH; p[EH] = x.endH; p[AUTO] = x.autoStart
        }
    }
}
