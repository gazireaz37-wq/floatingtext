package com.example.floatingtext

import android.content.*
import android.provider.Settings
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val pr = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val cfg = Prefs.flow(c).first()
                if (cfg.autoStart && Settings.canDrawOverlays(c))
                    c.startForegroundService(Intent(c, FloatingTextService::class.java))
            } finally { pr.finish() }
        }
    }
}
