package com.example.floatingtext

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collect
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

class FloatingTextService : Service() {

    private lateinit var wm: WindowManager
    private var tv: TextView? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var cfg = Cfg()
    private var texts = listOf("")
    private var running = false
    private var lastNs = 0L
    private var px = 100f; private var py = 200f
    private var dirX = 1f; private var dirY = 1f
    private var tx = 0f; private var ty = 0f
    private var idx = 0; private var rotAcc = 0f; private var schedAcc = 99f
    private var hidden = false
    private var dragDX = 0f; private var dragDY = 0f

    // ---------- ফ্রেম লুপ (Choreographer: মসৃণ ও ব্যাটারি-বান্ধব) ----------
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(ns: Long) {
            val v = tv ?: return
            val dt = if (lastNs == 0L) 0.016f else ((ns - lastNs) / 1e9f).coerceAtMost(0.05f)
            lastNs = ns
            tick(v, dt)
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun tick(v: TextView, dt: Float) {
        val d = resources.displayMetrics          // রোটেশনেও প্রতি ফ্রেমে নতুন মাপ পায়
        val sp = cfg.speed * d.density
        val maxX = (d.widthPixels - v.width).coerceAtLeast(0).toFloat()
        val maxY = (d.heightPixels - v.height).coerceAtLeast(0).toFloat()

        // একাধিক লেখা ঘোরানো
        if (texts.size > 1) {
            rotAcc += dt
            if (rotAcc >= cfg.rotateSec) { rotAcc = 0f; idx = (idx + 1) % texts.size; v.text = texts[idx] }
        }
        // শিডিউল (সেকেন্ডে একবার চেক)
        schedAcc += dt
        if (schedAcc >= 1f) {
            schedAcc = 0f
            val show = inSchedule()
            if (show == hidden) { hidden = !show; v.visibility = if (show) View.VISIBLE else View.INVISIBLE }
        }
        if (hidden) return

        if (!cfg.draggable) when (cfg.mode) {
            "BOUNCE" -> {
                px += dirX * sp * dt; py += dirY * sp * dt
                if (px <= 0f) { px = 0f; dirX = 1f } else if (px >= maxX) { px = maxX; dirX = -1f }
                if (py <= 0f) { py = 0f; dirY = 1f } else if (py >= maxY) { py = maxY; dirY = -1f }
            }
            "RANDOM" -> {
                val dist = hypot(tx - px, ty - py)
                if (dist < 10f) { tx = Random.nextFloat() * maxX; ty = Random.nextFloat() * maxY }
                else { val s = sp * dt / dist; px += (tx - px) * s; py += (ty - py) * s }
            }
            "SCROLL" -> {
                px -= sp * dt
                if (px < -v.width) px = d.widthPixels.toFloat()
                py = d.heightPixels * 0.2f
            }
            else -> { px = maxX / 2; py = maxY / 2 }   // STATIC
        }
        lp.x = px.toInt(); lp.y = py.toInt()
        wm.updateViewLayout(v, lp)
    }

    private fun inSchedule(): Boolean {
        if (!cfg.schedOn) return true
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (cfg.startH <= cfg.endH) h in cfg.startH until cfg.endH else h >= cfg.startH || h < cfg.endH
    }

    // ---------- স্ক্রিন বন্ধ হলে অ্যানিমেশন থামে (ব্যাটারি বাঁচে) ----------
    private val screenRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF) pause() else resume()
        }
    }
    private fun pause() { running = false; Choreographer.getInstance().removeFrameCallback(frame) }
    private fun resume() {
        if (running || tv == null) return
        running = true; lastNs = 0L
        Choreographer.getInstance().postFrameCallback(frame)
    }

    // ---------- লাইফসাইকেল ----------
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        startAsForeground()
        if (tv == null) {
            addOverlay()
            ContextCompat.registerReceiver(this, screenRx,
                IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) },
                ContextCompat.RECEIVER_NOT_EXPORTED)
            scope.launch { Prefs.flow(this@FloatingTextService).collect { cfg = it; applyStyle() } }
            resume()
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ft", "Floating Text", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0,
            Intent(this, FloatingTextService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "ft")
            .setContentTitle("ফ্লোটিং টেক্সট চলছে")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_delete), "বন্ধ করুন", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun addOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tv = TextView(this).apply {
            setPadding(32, 16, 32, 16)
            setOnTouchListener { _, e ->
                if (!cfg.draggable) false else {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { dragDX = e.rawX - px; dragDY = e.rawY - py }
                        MotionEvent.ACTION_MOVE -> { px = e.rawX - dragDX; py = e.rawY - dragDY }
                    }
                    true
                }
            }
        }
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            baseFlags(), PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(tv, lp)
    }

    private fun baseFlags() = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun applyStyle() {
        val v = tv ?: return
        texts = cfg.texts.lines().filter { it.isNotBlank() }.ifEmpty { listOf(" ") }
        idx = idx.coerceIn(0, texts.size - 1)
        v.text = texts[idx]
        v.textSize = cfg.sizeSp
        v.setTextColor(cfg.color)
        v.alpha = cfg.alpha
        v.background = GradientDrawable().apply { cornerRadius = 32f; setColor(0x99000000.toInt()) }
        lp.flags = if (cfg.draggable) baseFlags() else baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(v, lp)
    }

    override fun onDestroy() {
        pause()
        scope.cancel()
        runCatching { unregisterReceiver(screenRx) }
        tv?.let { wm.removeView(it) }
        tv = null
        super.onDestroy()
    }
}
