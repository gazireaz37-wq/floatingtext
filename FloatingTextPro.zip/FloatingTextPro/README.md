# Floating Text Pro

## চালানোর ধাপ
1. Android Studio-তে এই ফোল্ডার খুলুন → Gradle Sync।
2. ফোনে Run করুন → "অন্য অ্যাপের উপরে দেখানো" পারমিশন দিন → চালু করুন।

## Play Store চেকলিস্ট
- applicationId ও privacy policy-র ইমেইল বদলান; আইকন ও স্ক্রিনশট যোগ করুন।
- Play Console → App content → Foreground service (specialUse) ঘোষণা দিন এবং ভিডিও/ব্যাখ্যা দিন।
- Permissions Declaration-এ SYSTEM_ALERT_WINDOW-এর কারণ লিখুন।
- Crashlytics: build.gradle.kts-এর কমেন্ট খুলুন ও google-services.json বসান।
- Release: Build → Generate Signed Bundle (R8 চালু আছে)।

## GitHub দিয়ে বিল্ড
1. GitHub-এ নতুন repository বানান, এই ফোল্ডারের সব ফাইল (`.github` সহ) আপলোড করুন।
2. Actions ট্যাব → "Build APK" → Run workflow।
3. শেষ হলে (৩-৫ মিনিট) রান পেজের Artifacts থেকে APK ডাউনলোড করুন।
