# Privacy Policy — Floating Text Pro

Floating Text Pro does not collect, store, or share any personal data. All settings (text, colour, speed, etc.) are stored only on your device.

**Permissions**
- *Display over other apps* — to show your text above other apps.
- *Foreground service / Notifications* — to keep the overlay running and show a Stop button.
- *Receive boot completed* — only if you enable auto-start.

The app does not use the internet. Contact: your-email@example.com
